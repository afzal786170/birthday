
import { useEffect, useState } from "react";
import confetti from "canvas-confetti";
const backgroundMusic = new Audio("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3");

function App() {
  const [name, setName] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    backgroundMusic.play();
    backgroundMusic.loop = true;
    return () => backgroundMusic.pause();
  }, []);

  useEffect(() => {
    if (submitted) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  }, [submitted]);

  const shareMessage = `Janamdin Mubarak, ${name}! Ek khoobsurat dua tumhare liye: \"Tere jese log khuda ki rehmat hote hain...\"`;

  return (
    <div style={{ fontFamily: "'Noto Nastaliq Urdu', cursive", minHeight: "100vh", background: "linear-gradient(to bottom right, #fcefe8, #d1fae5, #dbeafe)", display: "flex", alignItems: "center", justifyContent: "center", padding: "2rem", flexDirection: "column" }}>
      {!submitted ? (
        <div style={{ textAlign: "center", maxWidth: "400px", background: "#ffffffcc", padding: "1.5rem", borderRadius: "1rem", boxShadow: "0 10px 25px rgba(0,0,0,0.1)" }}>
          <h2 style={{ fontSize: "1.5rem", color: "#047857", marginBottom: "1rem" }}>Naam likho jise birthday wish karni hai:</h2>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Naam yahan likho" style={{ width: "100%", padding: "0.5rem", borderRadius: "0.5rem", border: "1px solid #ccc", marginBottom: "1rem" }} />
          <button onClick={() => setSubmitted(true)} style={{ backgroundColor: "#047857", color: "white", padding: "0.5rem 1rem", borderRadius: "0.5rem" }}>WISH BHEJO</button>
        </div>
      ) : (
        <div style={{ textAlign: "center", maxWidth: "600px", background: "#ffffffcc", padding: "1.5rem", borderRadius: "1rem", boxShadow: "0 10px 25px rgba(0,0,0,0.1)" }}>
          <h1 style={{ fontSize: "2rem", color: "#065f46", marginBottom: "1rem" }}>Janamdin Mubarak, {name}!</h1>
          <p style={{ fontSize: "1.1rem", fontStyle: "italic", color: "#333" }}>"Tere jese log khuda ki rehmat hote hain, har pal dua hai ke teri zindagi gulabon se mehka rahe."</p>
          <p style={{ marginTop: "1rem", fontSize: "0.9rem", color: "#666" }}>— Ek dua dil se, tumhare is khaas din ke liye</p>
          <img src="https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?auto=format&fit=crop&w=800&q=80" alt="Nature and Flowers" style={{ borderRadius: "1rem", marginTop: "1.5rem", width: "100%", boxShadow: "0 5px 15px rgba(0,0,0,0.1)" }} />
          <button onClick={() => navigator.share && navigator.share({ title: "Birthday Wish", text: shareMessage })} style={{ marginTop: "1rem", backgroundColor: "#be185d", color: "white", padding: "0.5rem 1rem", borderRadius: "0.5rem" }}>SHARE KARO</button>
        </div>
      )}
    </div>
  );
}

export default App;
